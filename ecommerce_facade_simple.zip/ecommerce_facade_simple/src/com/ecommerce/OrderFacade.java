package com.ecommerce;

public abstract class OrderFacade {
    public abstract boolean placeOrder(String productId, String customerId, String address, double amount);
}
