package com.ecommerce;

public class ShippingService {
    public void scheduleDelivery(String productId, String address) {
        System.out.println("Delivery of " + productId + " to " + address);
    }
}
