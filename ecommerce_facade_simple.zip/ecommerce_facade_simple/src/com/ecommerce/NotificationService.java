package com.ecommerce;

public class NotificationService {
    public void sendReceipt(String customerId, double amount) {
        System.out.println("Receipt sent to " + customerId + " for " + amount);
    }
}
