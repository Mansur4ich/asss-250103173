package com.ecommerce;

public class PaymentGateway {
    public boolean charge(String customerId, double amount) {
        if (customerId == null || customerId.isEmpty() || amount <= 0) {
            return false;
        }
        System.out.println("Payment: " + amount);
        return true;
    }
}
