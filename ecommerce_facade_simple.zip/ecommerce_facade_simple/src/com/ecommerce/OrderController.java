package com.ecommerce;

public class OrderController {
    public static void main(String[] args) {
        OrderFacade checkout = new CheckoutFacade();
        boolean success = checkout.placeOrder("Laptop", "student01", "Almaty", 250000);

        if (success) {
            System.out.println("Order completed!");
        } else {
            System.out.println("Order failed!");
        }
    }
}
