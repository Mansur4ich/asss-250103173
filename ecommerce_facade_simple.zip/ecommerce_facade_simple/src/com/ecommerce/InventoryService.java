package com.ecommerce;

public class InventoryService {
    public boolean checkStock(String productId) {
        System.out.println("Checking stock: " + productId);
        return productId != null && !productId.isEmpty();
    }

    public void reserve(String productId) {
        System.out.println("Reserved: " + productId);
    }
}
