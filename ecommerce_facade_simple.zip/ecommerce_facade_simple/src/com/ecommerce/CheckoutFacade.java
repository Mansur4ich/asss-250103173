package com.ecommerce;

public class CheckoutFacade extends OrderFacade {
    private final InventoryService inventory = new InventoryService();
    private final PaymentGateway payment = new PaymentGateway();
    private final ShippingService shipping = new ShippingService();
    private final NotificationService notification = new NotificationService();

    @Override
    public boolean placeOrder(String productId, String customerId, String address, double amount) {
        if (!inventory.checkStock(productId)) {
            System.out.println("Product not found");
            return false;
        }

        if (!payment.charge(customerId, amount)) {
            System.out.println("Payment failed");
            return false;
        }

        inventory.reserve(productId);
        shipping.scheduleDelivery(productId, address);
        notification.sendReceipt(customerId, amount);
        return true;
    }
}
