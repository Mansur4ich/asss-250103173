Simple E-Commerce Facade Pattern Project

Pattern: Facade
Abstraction: abstract class OrderFacade

Folder: src/com/ecommerce

Windows / Command Prompt:
cd src
javac com\ecommerce\*.java
java com.ecommerce.OrderController

Run using an IDE:
Open the src folder as the source root and run OrderController.main().

Main classes:
OrderController -> OrderFacade -> CheckoutFacade -> InventoryService, PaymentGateway, ShippingService, NotificationService

All operations are simulated for a classroom demonstration.
